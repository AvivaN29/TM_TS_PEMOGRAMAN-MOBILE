import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PemesananPage extends StatefulWidget {
  const PemesananPage({super.key});

  @override
  State<PemesananPage> createState() => _PemesananPageState();
}

class _PemesananPageState extends State<PemesananPage> {
  final _namaC = TextEditingController();
  final _beratC = TextEditingController();

  String _layanan = 'Cuci Kering';
  double _harga = 10000;
  double _total = 0;

  final List<Map<String, dynamic>> _layananList = [
    {'nama': 'Cuci Kering', 'harga': 10000},
    {'nama': 'Cuci Setrika', 'harga': 15000},
    {'nama': 'Setrika Saja', 'harga': 8000},
  ];

  void _hitungTotal() {
    final berat = double.tryParse(_beratC.text) ?? 0;
    setState(() {
      _total = berat * _harga;
    });
  }

  Future<void> _simpanPemesanan() async {
    if (_namaC.text.isEmpty || _beratC.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Lengkapi data')));
      return;
    }

    await FirebaseFirestore.instance.collection('pemesanan').add({
      'nama': _namaC.text.trim(),
      'layanan': _layanan,
      'berat': double.parse(_beratC.text),
      'harga': _harga,
      'total': _total,
      'tanggal': DateTime.now().toString().substring(0, 10),
      'createdAt': Timestamp.now(),
    });

    if (!mounted) return;

    _namaC.clear();
    _beratC.clear();

    setState(() {
      _total = 0;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Pemesanan berhasil disimpan'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Form Pemesanan'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            // NAMA
            TextField(
              controller: _namaC,
              decoration: const InputDecoration(
                labelText: 'Nama Pelanggan',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),

            // LAYANAN (FIX DEPRECATED)
            DropdownButtonFormField<String>(
              initialValue: _layanan,
              decoration: const InputDecoration(
                labelText: 'Jenis Layanan',
                border: OutlineInputBorder(),
              ),
              items: _layananList.map((item) {
                return DropdownMenuItem<String>(
                  value: item['nama'],
                  child: Text('${item['nama']} (Rp ${item['harga']}/kg)'),
                );
              }).toList(),
              onChanged: (value) {
                final selected = _layananList.firstWhere(
                  (e) => e['nama'] == value,
                );
                setState(() {
                  _layanan = value!;
                  _harga = selected['harga'];
                });
                _hitungTotal();
              },
            ),
            const SizedBox(height: 16),

            // BERAT
            TextField(
              controller: _beratC,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Berat (Kg)',
                border: OutlineInputBorder(),
              ),
              onChanged: (_) => _hitungTotal(),
            ),
            const SizedBox(height: 20),

            // TOTAL
            Text(
              'Total: Rp ${_total.toStringAsFixed(0)}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),

            // SIMPAN
            SizedBox(
              height: 48,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                ),
                icon: const Icon(Icons.save),
                label: const Text('Simpan Pemesanan'),
                onPressed: _simpanPemesanan,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
