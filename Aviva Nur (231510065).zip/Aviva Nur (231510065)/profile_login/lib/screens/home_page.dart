import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScrollController _scrollController = ScrollController();
  bool showSection = false;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.offset > 250 && !showSection) {
        setState(() => showSection = true);
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        controller: _scrollController,
        child: Column(
          children: [
            // ================= HERO =================
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 100),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF43A047), Color(0xFF66BB6A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                children: [
                  const Text(
                    'Abang Laundry',
                    style: TextStyle(
                      fontSize: 46,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Laundry Bersih • Cepat • Terpercaya',
                    style: TextStyle(fontSize: 20, color: Colors.white70),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 30,
                        vertical: 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    onPressed: () {},
                    child: const Text(
                      'Lihat Layanan',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ],
              ),
            ),

            // ================= LAYANAN =================
            _sectionContainer(
              child: Column(
                children: [
                  _sectionTitle('Layanan Kami'),
                  const SizedBox(height: 40),
                  _animatedWrap(
                    GridView.count(
                      crossAxisCount: MediaQuery.of(context).size.width < 800
                          ? 1
                          : 3,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 24,
                      mainAxisSpacing: 24,
                      children: const [
                        _ServiceCard(
                          icon: Icons.local_laundry_service,
                          title: 'Cuci Reguler',
                          desc: 'Proses cepat, bersih dan wangi tahan lama.',
                        ),
                        _ServiceCard(
                          icon: Icons.diamond,
                          title: 'Laundry Eksklusif',
                          desc: 'Perawatan khusus untuk pakaian premium.',
                        ),
                        _ServiceCard(
                          icon: Icons.checkroom,
                          title: 'Cuci Sepatu & Bed Cover',
                          desc: 'Peralatan khusus tanpa merusak bahan.',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // ================= KEUNGGULAN =================
            Container(
              width: double.infinity,
              color: const Color(0xFFF5F5F5),
              padding: const EdgeInsets.all(60),
              child: Column(
                children: [
                  _sectionTitle('Kenapa Abang Laundry?'),
                  const SizedBox(height: 30),
                  _animatedWrap(
                    Wrap(
                      spacing: 30,
                      runSpacing: 30,
                      alignment: WrapAlignment.center,
                      children: const [
                        _ValueItem(
                          icon: Icons.eco,
                          text: 'Detergen Ramah Lingkungan',
                        ),
                        _ValueItem(icon: Icons.schedule, text: 'Tepat Waktu'),
                        _ValueItem(
                          icon: Icons.payments,
                          text: 'Pembayaran Mudah',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // ================= CTA =================
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 80),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF66BB6A), Color(0xFF81C784)],
                ),
              ),
              child: Column(
                children: const [
                  Text(
                    'Siap Laundry Tanpa Ribet?',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Percayakan pakaian Anda kepada Abang Laundry',
                    style: TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================= HELPER =================

  Widget _animatedWrap(Widget child) {
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 700),
      opacity: showSection ? 1 : 0,
      child: AnimatedSlide(
        duration: const Duration(milliseconds: 700),
        offset: showSection ? Offset.zero : const Offset(0, 0.15),
        child: child,
      ),
    );
  }

  static Widget _sectionContainer({required Widget child}) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 1200),
      padding: const EdgeInsets.all(60),
      child: child,
    );
  }

  static Widget _sectionTitle(String text) {
    return Text(
      text,
      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
    );
  }
}

// ================= COMPONENT =================

class _ServiceCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;

  const _ServiceCard({
    required this.icon,
    required this.title,
    required this.desc,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, size: 48, color: Colors.green),
          const SizedBox(height: 20),
          Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Text(desc, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _ValueItem extends StatelessWidget {
  final IconData icon;
  final String text;

  const _ValueItem({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: Colors.green.shade100,
          child: Icon(icon, color: Colors.green, size: 30),
        ),
        const SizedBox(height: 12),
        Text(text),
      ],
    );
  }
}
