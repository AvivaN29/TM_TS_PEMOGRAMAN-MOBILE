import 'package:flutter/material.dart';

class PelangganPage extends StatefulWidget {
  const PelangganPage({super.key});

  @override
  State<PelangganPage> createState() => _PelangganPageState();
}

class _PelangganPageState extends State<PelangganPage> {
  final List<Map<String, String>> _pelanggan = [];
  List<Map<String, String>> _filtered = [];

  final TextEditingController _searchC = TextEditingController();

  @override
  void initState() {
    super.initState();
    _filtered = _pelanggan;
  }

  void _tambahPelanggan(String nama, String hp) {
    setState(() {
      _pelanggan.add({'nama': nama, 'hp': hp});
      _filtered = _pelanggan;
    });
  }

  void _hapusPelanggan(int index) {
    setState(() {
      _pelanggan.removeAt(index);
      _filtered = _pelanggan;
    });
  }

  void _search(String keyword) {
    setState(() {
      _filtered = _pelanggan
          .where(
            (item) =>
                item['nama']!.toLowerCase().contains(keyword.toLowerCase()),
          )
          .toList();
    });
  }

  void _dialogTambah() {
    final namaC = TextEditingController();
    final hpC = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Tambah Pelanggan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: namaC,
              decoration: const InputDecoration(labelText: 'Nama'),
            ),
            TextField(
              controller: hpC,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'No HP'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              if (namaC.text.isNotEmpty && hpC.text.isNotEmpty) {
                _tambahPelanggan(namaC.text, hpC.text);
                Navigator.pop(context);
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Pelanggan'),
        backgroundColor: Colors.deepPurple,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.deepPurple,
        onPressed: _dialogTambah,
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          // 🔍 SEARCH BAR
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchC,
              onChanged: _search,
              decoration: InputDecoration(
                hintText: 'Cari pelanggan...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),

          // LIST DATA
          Expanded(
            child: _filtered.isEmpty
                ? const Center(child: Text('Data pelanggan tidak ditemukan'))
                : ListView.builder(
                    itemCount: _filtered.length,
                    itemBuilder: (context, index) {
                      final item = _filtered[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: ListTile(
                          leading: const Icon(Icons.person),
                          title: Text(item['nama']!),
                          subtitle: Text('HP: ${item['hp']}'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              final realIndex = _pelanggan.indexOf(item);
                              _hapusPelanggan(realIndex);
                            },
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
