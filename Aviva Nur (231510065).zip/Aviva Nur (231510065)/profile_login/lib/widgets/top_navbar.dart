import 'package:flutter/material.dart';
import '../screens/login_page.dart';

class TopNavbar extends StatelessWidget {
  final Function(String) onMenuTap;

  const TopNavbar({super.key, required this.onMenuTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      color: Colors.white,
      child: Row(
        children: [
          const Text(
            'Abang Laundry',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.deepPurple,
            ),
          ),
          const SizedBox(width: 40),

          _menu(context, 'Home'),
          _menu(context, 'Temukan Alasan'),
          _menu(context, 'Promo'),
          _menu(context, 'Layanan'),
          _menu(context, 'Apa Kabar'),
          _menu(context, 'Contact'),

          const Spacer(),

          // 🔴 LOGOUT BUTTON
          IconButton(
            tooltip: 'Logout',
            icon: const Icon(Icons.logout, color: Colors.red),
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _menu(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: InkWell(
        onTap: () => onMenuTap(title),
        child: Text(
          title,
          style: const TextStyle(color: Colors.green, fontSize: 14),
        ),
      ),
    );
  }
}
