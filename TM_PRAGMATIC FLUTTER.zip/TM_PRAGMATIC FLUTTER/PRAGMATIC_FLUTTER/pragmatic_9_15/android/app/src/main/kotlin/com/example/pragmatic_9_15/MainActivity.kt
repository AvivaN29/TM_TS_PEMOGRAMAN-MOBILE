package com.example.pragmatic_9_15

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
