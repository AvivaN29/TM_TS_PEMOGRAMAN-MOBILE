import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Simple math test', () {
    test('1 + 1 = 2', () {
      expect(1 + 1, equals(2));
    });

    test('2 * 3 = 6', () {
      expect(2 * 3, equals(6));
    });

    test('5 - 3 = 2', () {
      expect(5 - 3, equals(2));
    });
  });
}
