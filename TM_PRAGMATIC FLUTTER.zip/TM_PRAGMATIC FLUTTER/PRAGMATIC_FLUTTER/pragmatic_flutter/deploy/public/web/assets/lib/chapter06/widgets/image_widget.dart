import 'package:flutter/material.dart';

class ImageWidget extends StatelessWidget {
  const ImageWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Image.network(
      'https://flutter.dev/assets/homepage/carousel/slide_1-bg-opaque-4e2fcef2c57d205c3bd6c3a44aef0f9b8677183762c508d57f075444ef98b6c3.png',
      width: 200,
    );
  }
}
