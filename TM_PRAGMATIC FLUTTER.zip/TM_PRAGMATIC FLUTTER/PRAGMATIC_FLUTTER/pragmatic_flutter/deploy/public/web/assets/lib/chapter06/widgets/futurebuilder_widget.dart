import 'package:flutter/material.dart';

class FutureBuilderWidget extends StatelessWidget {
  const FutureBuilderWidget({Key? key}) : super(key: key);

  Future<String> _loadData() async {
    await Future.delayed(const Duration(seconds: 2));
    return 'Data berhasil dimuat';
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _loadData(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const CircularProgressIndicator();
        } else if (snapshot.hasError) {
          return const Text('Terjadi kesalahan');
        } else {
          return Text(snapshot.data ?? '');
        }
      },
    );
  }
}
