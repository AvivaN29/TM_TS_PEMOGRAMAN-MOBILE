import 'package:flutter/material.dart';

class FittedBoxExample extends StatefulWidget {
  const FittedBoxExample({Key? key}) : super(key: key);

  @override
  State<FittedBoxExample> createState() => _FittedBoxExampleState();
}

class _FittedBoxExampleState extends State<FittedBoxExample> {
  /// DEFAULT VALUE WAJIB
  String fittedType = 'contain';

  BoxFit _getBoxFit() {
    switch (fittedType) {
      case 'cover':
        return BoxFit.cover;
      case 'fill':
        return BoxFit.fill;
      case 'fitWidth':
        return BoxFit.fitWidth;
      case 'fitHeight':
        return BoxFit.fitHeight;
      default:
        return BoxFit.contain;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('FittedBox Example'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          DropdownButton<String>(
            value: fittedType,
            items: const [
              DropdownMenuItem(
                value: 'contain',
                child: Text('contain'),
              ),
              DropdownMenuItem(
                value: 'cover',
                child: Text('cover'),
              ),
              DropdownMenuItem(
                value: 'fill',
                child: Text('fill'),
              ),
              DropdownMenuItem(
                value: 'fitWidth',
                child: Text('fitWidth'),
              ),
              DropdownMenuItem(
                value: 'fitHeight',
                child: Text('fitHeight'),
              ),
            ],
            onChanged: (String? value) {
              if (value == null) return;
              setState(() {
                fittedType = value;
              });
            },
          ),
          const SizedBox(height: 20),
          Expanded(
            child: Center(
              child: Container(
                width: 200,
                height: 200,
                color: Colors.grey.shade300,
                child: FittedBox(
                  fit: _getBoxFit(),
                  child: Container(
                    width: 300,
                    height: 150,
                    color: Colors.blue,
                    child: const Center(
                      child: Text(
                        'FittedBox',
                        style: TextStyle(color: Colors.white, fontSize: 24),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
