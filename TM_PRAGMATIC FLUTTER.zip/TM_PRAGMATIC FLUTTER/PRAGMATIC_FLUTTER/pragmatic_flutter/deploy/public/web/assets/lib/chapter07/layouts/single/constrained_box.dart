import 'package:flutter/material.dart';

class ConstrainedBoxExample extends StatefulWidget {
  const ConstrainedBoxExample({Key? key}) : super(key: key);

  @override
  State<ConstrainedBoxExample> createState() => _ConstrainedBoxExampleState();
}

class _ConstrainedBoxExampleState extends State<ConstrainedBoxExample> {
  /// STATE WAJIB ADA DEFAULT
  String currentConstraint = 'Small';

  BoxConstraints _getConstraints(String type) {
    switch (type) {
      case 'Medium':
        return const BoxConstraints(
          minWidth: 150,
          minHeight: 150,
          maxWidth: 200,
          maxHeight: 200,
        );
      case 'Large':
        return const BoxConstraints(
          minWidth: 250,
          minHeight: 250,
          maxWidth: 300,
          maxHeight: 300,
        );
      default:
        return const BoxConstraints(
          minWidth: 100,
          minHeight: 100,
          maxWidth: 120,
          maxHeight: 120,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ConstrainedBox Example'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          DropdownButton<String>(
            value: currentConstraint,
            items: const [
              DropdownMenuItem(
                value: 'Small',
                child: Text('Small'),
              ),
              DropdownMenuItem(
                value: 'Medium',
                child: Text('Medium'),
              ),
              DropdownMenuItem(
                value: 'Large',
                child: Text('Large'),
              ),
            ],
            onChanged: (String? value) {
              if (value == null) return;
              setState(() {
                currentConstraint = value;
              });
            },
          ),
          const SizedBox(height: 20),
          Center(
            child: ConstrainedBox(
              constraints: _getConstraints(currentConstraint),
              child: Container(
                color: Colors.blue,
                child: const Center(
                  child: Text(
                    'Constrained Box',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
