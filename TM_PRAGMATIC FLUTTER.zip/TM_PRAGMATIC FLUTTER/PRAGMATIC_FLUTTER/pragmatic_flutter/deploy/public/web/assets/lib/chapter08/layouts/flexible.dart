import 'package:flutter/material.dart';

class FlexibleExample extends StatefulWidget {
  const FlexibleExample({Key? key}) : super(key: key);

  @override
  State<FlexibleExample> createState() => _FlexibleExampleState();
}

class _FlexibleExampleState extends State<FlexibleExample> {
  /// DEFAULT VALUE WAJIB
  String flexType = 'tight';

  FlexFit _getFlexFit() {
    switch (flexType) {
      case 'loose':
        return FlexFit.loose;
      default:
        return FlexFit.tight;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flexible Example'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          DropdownButton<String>(
            value: flexType,
            items: const [
              DropdownMenuItem(
                value: 'tight',
                child: Text('tight'),
              ),
              DropdownMenuItem(
                value: 'loose',
                child: Text('loose'),
              ),
            ],
            onChanged: (String? value) {
              if (value == null) return;
              setState(() {
                flexType = value;
              });
            },
          ),
          const SizedBox(height: 20),
          Expanded(
            child: Row(
              children: [
                Flexible(
                  fit: _getFlexFit(),
                  child: Container(
                    color: Colors.blue,
                    child: const Center(
                      child: Text(
                        'Flexible 1',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
                Container(
                  width: 100,
                  color: Colors.red,
                  child: const Center(
                    child: Text(
                      'Fixed',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                Flexible(
                  fit: _getFlexFit(),
                  child: Container(
                    color: Colors.green,
                    child: const Center(
                      child: Text(
                        'Flexible 2',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
