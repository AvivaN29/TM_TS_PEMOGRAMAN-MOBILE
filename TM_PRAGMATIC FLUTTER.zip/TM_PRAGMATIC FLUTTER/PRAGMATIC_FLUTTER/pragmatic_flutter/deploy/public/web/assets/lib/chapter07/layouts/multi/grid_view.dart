import 'package:flutter/material.dart';

class GridViewExample extends StatelessWidget {
  const GridViewExample({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      children: const [
        Card(child: Center(child: Text('Item 1'))),
        Card(child: Center(child: Text('Item 2'))),
        Card(child: Center(child: Text('Item 3'))),
        Card(child: Center(child: Text('Item 4'))),
      ],
    );
  }
}
