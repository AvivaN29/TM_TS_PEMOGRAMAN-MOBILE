import 'package:flutter/material.dart';

class PaddingExample extends StatefulWidget {
  const PaddingExample({Key? key}) : super(key: key);

  @override
  State<PaddingExample> createState() => _PaddingExampleState();
}

class _PaddingExampleState extends State<PaddingExample> {
  /// STATE WAJIB ADA DEFAULT
  String dropDownValue = 'Small';

  EdgeInsets _getPadding(String value) {
    switch (value) {
      case 'Medium':
        return const EdgeInsets.all(24);
      case 'Large':
        return const EdgeInsets.all(48);
      default:
        return const EdgeInsets.all(12);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Padding Example'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          DropdownButton<String>(
            value: dropDownValue,
            items: const [
              DropdownMenuItem(
                value: 'Small',
                child: Text('Small'),
              ),
              DropdownMenuItem(
                value: 'Medium',
                child: Text('Medium'),
              ),
              DropdownMenuItem(
                value: 'Large',
                child: Text('Large'),
              ),
            ],
            onChanged: (String? value) {
              if (value == null) return;
              setState(() {
                dropDownValue = value;
              });
            },
          ),
          const SizedBox(height: 20),
          Padding(
            padding: _getPadding(dropDownValue),
            child: Container(
              color: Colors.blue,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Text(
                  'Padding Example',
                  style: Theme.of(context)
                      .textTheme
                      .bodyLarge
                      ?.copyWith(color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
