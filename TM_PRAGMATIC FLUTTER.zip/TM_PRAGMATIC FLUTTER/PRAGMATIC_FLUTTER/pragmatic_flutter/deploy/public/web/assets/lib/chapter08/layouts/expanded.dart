import 'package:flutter/material.dart';

class ExpandedExample extends StatefulWidget {
  const ExpandedExample({Key? key}) : super(key: key);

  @override
  State<ExpandedExample> createState() => _ExpandedExampleState();
}

class _ExpandedExampleState extends State<ExpandedExample> {
  /// DEFAULT VALUE WAJIB
  String expandedType = 'Equal';

  List<Widget> _buildExpandedWidgets() {
    switch (expandedType) {
      case 'Flex 1 : 2':
        return const [
          Expanded(
            flex: 1,
            child: ColoredBox(color: Colors.red),
          ),
          Expanded(
            flex: 2,
            child: ColoredBox(color: Colors.blue),
          ),
        ];
      default:
        return const [
          Expanded(
            child: ColoredBox(color: Colors.red),
          ),
          Expanded(
            child: ColoredBox(color: Colors.blue),
          ),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Expanded Example'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          DropdownButton<String>(
            value: expandedType,
            items: const [
              DropdownMenuItem(
                value: 'Equal',
                child: Text('Equal'),
              ),
              DropdownMenuItem(
                value: 'Flex 1 : 2',
                child: Text('Flex 1 : 2'),
              ),
            ],
            onChanged: (String? value) {
              if (value == null) return;
              setState(() {
                expandedType = value;
              });
            },
          ),
          const SizedBox(height: 20),
          Expanded(
            child: Row(
              children: _buildExpandedWidgets(),
            ),
          ),
        ],
      ),
    );
  }
}
