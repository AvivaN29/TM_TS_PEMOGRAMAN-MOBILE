import 'package:flutter/material.dart';

class ContainerExample extends StatefulWidget {
  const ContainerExample({Key? key}) : super(key: key);

  @override
  State<ContainerExample> createState() => _ContainerExampleState();
}

class _ContainerExampleState extends State<ContainerExample> {
  /// STATE WAJIB PUNYA DEFAULT
  String dropDownValue = 'Red';

  Color _getColor(String value) {
    switch (value) {
      case 'Green':
        return Colors.green;
      case 'Blue':
        return Colors.blue;
      default:
        return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Container Example'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          DropdownButton<String>(
            value: dropDownValue,
            items: const [
              DropdownMenuItem(
                value: 'Red',
                child: Text('Red'),
              ),
              DropdownMenuItem(
                value: 'Green',
                child: Text('Green'),
              ),
              DropdownMenuItem(
                value: 'Blue',
                child: Text('Blue'),
              ),
            ],
            onChanged: (String? value) {
              if (value == null) return;
              setState(() {
                dropDownValue = value;
              });
            },
          ),
          const SizedBox(height: 20),
          Center(
            child: Container(
              width: 150,
              height: 150,
              color: _getColor(dropDownValue),
              child: const Center(
                child: Text(
                  'Container',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
