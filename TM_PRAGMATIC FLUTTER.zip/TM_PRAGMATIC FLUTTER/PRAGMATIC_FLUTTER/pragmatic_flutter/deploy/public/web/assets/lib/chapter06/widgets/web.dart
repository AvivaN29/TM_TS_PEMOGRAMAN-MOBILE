import 'package:flutter/material.dart';

import 'reusable_widgets.dart';

Widget alertDialog(BuildContext context, String title, String content) {
  return materialAlertDialog(context, title, content);
}
