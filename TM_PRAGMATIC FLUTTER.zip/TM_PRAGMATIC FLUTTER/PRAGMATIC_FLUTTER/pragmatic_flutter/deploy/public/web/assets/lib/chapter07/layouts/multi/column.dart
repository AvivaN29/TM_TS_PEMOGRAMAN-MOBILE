import 'package:flutter/material.dart';

class ColumnLayoutExample extends StatelessWidget {
  const ColumnLayoutExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        Text('Item 1'),
        Text('Item 2'),
        Text('Item 3'),
      ],
    );
  }
}
