import 'package:flutter/material.dart';

class BookStore extends ChangeNotifier {
  final Set<String> _ownedBooks = {};

  bool isOwned(String bookId) {
    return _ownedBooks.contains(bookId);
  }

  void buyBook(String bookId) {
    _ownedBooks.add(bookId);
    notifyListeners();
  }
}
