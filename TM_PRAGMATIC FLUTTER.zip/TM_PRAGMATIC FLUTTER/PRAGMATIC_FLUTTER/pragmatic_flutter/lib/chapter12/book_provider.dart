import 'package:flutter/material.dart';

class BookProvider extends ChangeNotifier {
  final List<Map<String, dynamic>> _books = [
    {
      'title': 'Flutter for Beginners',
      'authors': ['Author One', 'Author Two'],
      'favorite': false,
    },
    {
      'title': 'Advanced Flutter',
      'authors': ['Author One'],
      'favorite': false,
    },
  ];

  List<Map<String, dynamic>> get books => _books;

  void toggleFavorite(int index) {
    _books[index]['favorite'] = !_books[index]['favorite'];
    notifyListeners();
  }
}
