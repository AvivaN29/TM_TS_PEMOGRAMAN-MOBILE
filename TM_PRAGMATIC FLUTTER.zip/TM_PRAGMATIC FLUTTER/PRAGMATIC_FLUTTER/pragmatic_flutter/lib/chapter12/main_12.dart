import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'book_provider.dart';

class BooksProviderApp extends StatelessWidget {
  const BooksProviderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => BookProvider(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Books App - Provider',
        home: const BooksHomePage(),
      ),
    );
  }
}

class BooksHomePage extends StatelessWidget {
  const BooksHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final bookProvider = context.watch<BookProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Books Listing (Provider)'),
      ),
      body: ListView.builder(
        itemCount: bookProvider.books.length,
        itemBuilder: (context, index) {
          final book = bookProvider.books[index];

          return Card(
            margin: const EdgeInsets.all(12),
            child: ListTile(
              title: Text(book['title']),
              subtitle: Text('Author(s): ${book['authors'].join(', ')}'),
              trailing: IconButton(
                icon: Icon(
                  book['favorite'] ? Icons.favorite : Icons.favorite_border,
                  color: book['favorite'] ? Colors.red : Colors.grey,
                ),
                onPressed: () {
                  bookProvider.toggleFavorite(index);
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
