import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../config.dart';
import 'book.dart';
import 'book_tile.dart';
import 'book_details_page.dart';

void main() {
  runApp(const Chapter15App());
}

class Chapter15App extends StatelessWidget {
  const Chapter15App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Chapter 15 - Books API',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: const BooksPage(),
    );
  }
}

class BooksPage extends StatefulWidget {
  const BooksPage({super.key});

  @override
  State<BooksPage> createState() => _BooksPageState();
}

class _BooksPageState extends State<BooksPage> {
  List<BookModel> books = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchBooks();
  }

  Future<void> fetchBooks() async {
    final uri = Uri.parse(
      '$googleBooksBaseUrl?q=flutter${googleBooksApiKey.isNotEmpty ? "&key=$googleBooksApiKey" : ""}',
    );

    final response = await http.get(uri);
    final data = json.decode(response.body);
    final List items = data['items'] ?? [];

    setState(() {
      books = items.map((e) => BookModel.fromJson(e)).toList();
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chapter 15 – Books API')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: books.length,
              itemBuilder: (context, index) {
                return BookTile(
                  book: books[index],
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BookDetailsPage(book: books[index]),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
