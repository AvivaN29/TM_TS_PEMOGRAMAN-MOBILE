class BookModel {
  final String title;
  final String authors;
  final String description;
  final String thumbnail;

  BookModel({
    required this.title,
    required this.authors,
    required this.description,
    required this.thumbnail,
  });

  factory BookModel.fromJson(Map<String, dynamic> json) {
    final volume = json['volumeInfo'] ?? {};
    final imageLinks = volume['imageLinks'] ?? {};

    return BookModel(
      title: volume['title'] ?? 'No Title',
      authors: (volume['authors'] != null)
          ? (volume['authors'] as List).join(', ')
          : 'Unknown Author',
      description: volume['description'] ?? 'No description available.',
      thumbnail: imageLinks['thumbnail'] ??
          'https://via.placeholder.com/128x180.png?text=No+Image',
    );
  }
}
