// theme_prefs.dart
// versi sederhana (pengganti MOOR lama)

class ThemePref {
  final int id;
  final bool isDark;

  ThemePref({
    required this.id,
    required this.isDark,
  });
}

class ThemePrefsDao {
  ThemePref _cache = ThemePref(id: 1, isDark: false);

  Future<ThemePref> getTheme() async {
    return _cache;
  }

  Future<void> saveTheme(bool isDark) async {
    _cache = ThemePref(id: 1, isDark: isDark);
  }

  Future<void> deleteTheme() async {
    _cache = ThemePref(id: 1, isDark: false);
  }
}
