// lib/chapter11/db/main_11_db.dart
// Demo / Stub Database (tanpa Drift, tanpa SQLite)

class MyDatabase {
  MyDatabase() {
    // simulasi inisialisasi database
    print('MyDatabase initialized (stub)');
  }

  /// Simpan tema (dummy)
  Future<void> saveTheme(String theme) async {
    print('Theme saved: $theme');
  }

  /// Ambil tema (dummy)
  Future<String> loadTheme() async {
    print('Theme loaded');
    return 'light';
  }

  /// Tutup database (dummy)
  Future<void> close() async {
    print('Database closed');
  }
}
