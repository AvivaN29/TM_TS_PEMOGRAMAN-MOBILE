// native.dart
// Stub database untuk platform native (tanpa Drift)

class NativeDatabase {
  NativeDatabase() {
    throw UnsupportedError(
      'Database is not implemented for native platform',
    );
  }
}
