// unsupported.dart
// Digunakan untuk platform yang tidak mendukung database

class UnsupportedDatabase {
  UnsupportedDatabase() {
    throw UnsupportedError(
      'Database is not supported on this platform',
    );
  }
}
