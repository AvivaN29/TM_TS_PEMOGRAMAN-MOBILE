// web.dart
// Stub database untuk platform web (tanpa Drift)

class WebDatabase {
  WebDatabase() {
    throw UnsupportedError(
      'Database is not supported on Web platform',
    );
  }
}
