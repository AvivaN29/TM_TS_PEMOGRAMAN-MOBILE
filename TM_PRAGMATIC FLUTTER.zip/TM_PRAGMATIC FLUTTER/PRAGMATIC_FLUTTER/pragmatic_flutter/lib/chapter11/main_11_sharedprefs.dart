// main_11_sharedprefs.dart
// Demo SharedPreferences (tanpa package)

class SharedPrefsDemo {
  String _theme = 'light';

  Future<void> saveTheme(String theme) async {
    _theme = theme;
    print('Theme saved (stub): $theme');
  }

  Future<String> loadTheme() async {
    print('Theme loaded (stub)');
    return _theme;
  }
}
