class Book {
  final String id;
  final String title;
  final String author;
  final String description;
  final String thumbnail;

  Book({
    required this.id,
    required this.title,
    required this.author,
    required this.description,
    required this.thumbnail,
  });

  factory Book.fromJson(Map<String, dynamic> json) {
    final volumeInfo = json['volumeInfo'] ?? {};

    // 🔹 Ambil thumbnail (aman)
    String thumb = volumeInfo['imageLinks']?['thumbnail'] ?? '';

    // 🔥 FIX untuk Flutter Web (http → https)
    thumb = thumb.replaceAll('http://', 'https://');

    return Book(
      id: json['id'] ?? '',
      title: volumeInfo['title'] ?? 'No Title',
      author:
          (volumeInfo['authors'] != null && volumeInfo['authors'].isNotEmpty)
              ? volumeInfo['authors'][0]
              : 'Unknown Author',
      description: volumeInfo['description'] ?? 'No description available.',
      thumbnail: thumb,
    );
  }
}
