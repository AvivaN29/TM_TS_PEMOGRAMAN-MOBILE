import 'package:flutter/material.dart';
import 'book.dart';
import 'book_detail_page.dart';

class BookTile extends StatelessWidget {
  final Book book;

  const BookTile({
    super.key,
    required this.book,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: book.thumbnail.isNotEmpty
          ? Image.network(
              book.thumbnail,
              width: 50,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.book),
            )
          : const Icon(Icons.book),
      title: Text(book.title),
      subtitle: Text(book.author),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BookDetailPage(book: book),
          ),
        );
      },
    );
  }
}
