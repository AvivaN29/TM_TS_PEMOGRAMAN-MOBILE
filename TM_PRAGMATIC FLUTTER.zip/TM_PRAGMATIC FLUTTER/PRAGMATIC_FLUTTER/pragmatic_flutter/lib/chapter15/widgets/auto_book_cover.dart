import 'package:flutter/material.dart';

class AutoBookCover extends StatelessWidget {
  final String title;

  const AutoBookCover({super.key, required this.title});

  String _initials(String title) {
    final words = title.split(' ');
    if (words.length == 1) {
      return words.first[0].toUpperCase();
    }
    return (words[0][0] + words[1][0]).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    final colors = [
      scheme.primaryContainer,
      scheme.secondaryContainer,
      scheme.tertiaryContainer,
    ];

    final bgColor = colors[title.hashCode.abs() % colors.length];

    return Container(
      width: 52,
      height: 72,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.menu_book, color: scheme.primary),
          const SizedBox(height: 4),
          Text(
            _initials(title),
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: scheme.primary,
            ),
          ),
        ],
      ),
    );
  }
}
