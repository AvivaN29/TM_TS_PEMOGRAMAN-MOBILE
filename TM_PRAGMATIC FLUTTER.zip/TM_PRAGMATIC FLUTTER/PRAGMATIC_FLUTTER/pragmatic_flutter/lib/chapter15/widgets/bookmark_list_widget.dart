import 'package:flutter/material.dart';
import '../../services/bookmark_service.dart';

class BookmarkListWidget extends StatefulWidget {
  final String bookTitle;
  final Function(int page) onJump;

  const BookmarkListWidget({
    super.key,
    required this.bookTitle,
    required this.onJump,
  });

  @override
  State<BookmarkListWidget> createState() => _BookmarkListWidgetState();
}

class _BookmarkListWidgetState extends State<BookmarkListWidget> {
  List<String> bookmarks = [];

  @override
  void initState() {
    super.initState();
    loadBookmarks();
  }

  Future<void> loadBookmarks() async {
    final data = await BookmarkService.getBookmarks();
    setState(() => bookmarks = data);
  }

  Future<void> remove(String bookmark) async {
    await BookmarkService.removeBookmark(bookmark);
    await loadBookmarks();
  }

  @override
  Widget build(BuildContext context) {
    if (bookmarks.isEmpty) {
      return const Text('Belum ada bookmark');
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '📌 Bookmark',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Wrap(
          spacing: 8,
          children: bookmarks.map((bookmark) {
            return Chip(
              label: Text(bookmark),
              deleteIcon: const Icon(Icons.close),
              onDeleted: () => remove(bookmark),
              avatar: const Icon(Icons.bookmark),
              backgroundColor: Colors.amber.shade100,
            );
          }).toList(),
        ),
      ],
    );
  }
}
