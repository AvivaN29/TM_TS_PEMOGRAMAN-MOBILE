import 'package:flutter/material.dart';
import '../../services/history_service.dart';

class LastReadWidget extends StatefulWidget {
  const LastReadWidget({super.key});

  @override
  State<LastReadWidget> createState() => _LastReadWidgetState();
}

class _LastReadWidgetState extends State<LastReadWidget> {
  String? lastBook;

  @override
  void initState() {
    super.initState();
    loadLast();
  }

  void loadLast() async {
    final list = await HistoryService.loadAll();
    if (list.isNotEmpty) {
      setState(() => lastBook = list.first);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (lastBook == null) {
      return const Text('Belum ada buku yang dibaca');
    }

    return Card(
      child: ListTile(
        title: Text(lastBook!),
        subtitle: const Text('Terakhir dibaca'),
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Membaca: $lastBook')),
          );
        },
      ),
    );
  }
}
