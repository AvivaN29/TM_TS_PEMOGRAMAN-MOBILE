import 'package:flutter/material.dart';

class ReadingHistoryWidget extends StatelessWidget {
  const ReadingHistoryWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: const [
            Icon(Icons.menu_book, size: 40, color: Colors.grey),
            SizedBox(height: 8),
            Text('Belum ada bacaan'),
            Text(
              'Mulai baca buku untuk melihat progres',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
