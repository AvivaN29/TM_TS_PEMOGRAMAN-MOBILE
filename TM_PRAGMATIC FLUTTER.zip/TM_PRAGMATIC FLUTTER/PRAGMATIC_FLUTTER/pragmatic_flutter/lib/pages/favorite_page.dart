import 'package:flutter/material.dart';
import '../services/favorite_service.dart';
import '../data/book_data.dart';

class FavoritePage extends StatelessWidget {
  const FavoritePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('❤️ Buku Favorit')),
      body: FutureBuilder<List<String>>(
        future: FavoriteService.getFavorites(),
        builder: (context, snapshot) {
          final favTitles = snapshot.data ?? [];
          final favBooks =
              books.where((b) => favTitles.contains(b.title)).toList();

          if (favBooks.isEmpty) {
            return const Center(child: Text('Belum ada favorit'));
          }

          return ListView.builder(
            itemCount: favBooks.length,
            itemBuilder: (_, i) {
              final book = favBooks[i];
              return ListTile(
                leading: Image.network(book.coverUrl, width: 50),
                title: Text(book.title),
                subtitle: Text(book.author),
              );
            },
          );
        },
      ),
    );
  }
}
