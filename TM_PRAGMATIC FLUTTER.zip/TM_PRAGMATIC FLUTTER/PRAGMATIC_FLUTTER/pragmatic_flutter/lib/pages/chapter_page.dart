import 'package:shared_preferences/shared_preferences.dart';

class ReadingProgressService {
  static const _keyPrefix = 'last_read_';

  /// Simpan chapter terakhir
  static Future<void> saveProgress(
    String bookTitle,
    String chapterTitle,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('$_keyPrefix$bookTitle', chapterTitle);
  }

  /// Ambil chapter terakhir
  static Future<String?> getLastRead(String bookTitle) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('$_keyPrefix$bookTitle');
  }
}
