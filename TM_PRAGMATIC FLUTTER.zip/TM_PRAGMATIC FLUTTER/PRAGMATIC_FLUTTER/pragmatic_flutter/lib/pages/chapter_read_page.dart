import 'package:flutter/material.dart';

class ChapterImage extends StatelessWidget {
  final String imageUrl;

  const ChapterImage({
    super.key,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network(
            imageUrl,
            height: 200, // ✅ BATASI TINGGI
            fit: BoxFit.contain, // ✅ TIDAK DIPAKSA
            loadingBuilder: (context, child, progress) {
              if (progress == null) return child;
              return const SizedBox(
                height: 200,
                child: Center(child: CircularProgressIndicator()),
              );
            },
            errorBuilder: (context, error, stackTrace) {
              return const SizedBox(
                height: 200,
                child: Center(child: Icon(Icons.broken_image, size: 40)),
              );
            },
          ),
        ),
      ),
    );
  }
}
