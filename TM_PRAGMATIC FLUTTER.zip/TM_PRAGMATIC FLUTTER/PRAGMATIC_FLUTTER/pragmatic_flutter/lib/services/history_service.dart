import 'package:shared_preferences/shared_preferences.dart';

class HistoryService {
  static const String _key = 'reading_history';

  // Simplified: just store titles instead of full Book objects
  static Future<void> save(String bookTitle) async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_key) ?? [];

    data.removeWhere((b) => b == bookTitle);
    data.insert(0, bookTitle);

    if (data.length > 10) {
      data.removeRange(10, data.length);
    }

    await prefs.setStringList(_key, data);
  }

  static Future<List<String>> loadAll() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_key) ?? [];
  }
}
