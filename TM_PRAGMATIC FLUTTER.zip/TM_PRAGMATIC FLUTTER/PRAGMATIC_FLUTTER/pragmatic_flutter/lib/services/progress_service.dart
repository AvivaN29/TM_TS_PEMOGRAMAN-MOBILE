import 'package:shared_preferences/shared_preferences.dart';

class ProgressService {
  static String _key(String bookId) => 'progress_$bookId';

  // simpan index chapter
  static Future<void> saveProgress(String bookId, int chapterIndex) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_key(bookId), chapterIndex);
  }

  // ambil index terakhir
  static Future<int> getProgress(String bookId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_key(bookId)) ?? 0;
  }

  // reset (opsional)
  static Future<void> reset(String bookId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key(bookId));
  }
}
