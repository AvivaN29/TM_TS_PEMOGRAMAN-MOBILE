import 'package:shared_preferences/shared_preferences.dart';

class BookmarkService {
  static const String _key = 'bookmarks';

  static Future<List<String>> getBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_key) ?? [];
  }

  static Future<void> addBookmark(String value) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarks = prefs.getStringList(_key) ?? [];
    if (!bookmarks.contains(value)) {
      bookmarks.add(value);
      await prefs.setStringList(_key, bookmarks);
    }
  }

  static Future<void> removeBookmark(String value) async {
    final prefs = await SharedPreferences.getInstance();
    final bookmarks = prefs.getStringList(_key) ?? [];
    bookmarks.remove(value);
    await prefs.setStringList(_key, bookmarks);
  }

  static Future<bool> isBookmarked(String value) async {
    final bookmarks = await getBookmarks();
    return bookmarks.contains(value);
  }
}
