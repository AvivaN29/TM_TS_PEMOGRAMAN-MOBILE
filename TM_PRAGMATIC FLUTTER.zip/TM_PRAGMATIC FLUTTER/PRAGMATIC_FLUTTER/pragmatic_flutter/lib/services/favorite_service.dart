import 'package:shared_preferences/shared_preferences.dart';

class FavoriteService {
  static const _key = 'favorite_books';

  static Future<List<String>> getFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_key) ?? [];
  }

  static Future<bool> isFavorite(String bookId) async {
    final favs = await getFavorites();
    return favs.contains(bookId);
  }

  static Future<void> toggleFavorite(String bookId) async {
    final prefs = await SharedPreferences.getInstance();
    final favs = prefs.getStringList(_key) ?? [];

    if (favs.contains(bookId)) {
      favs.remove(bookId);
    } else {
      favs.add(bookId);
    }

    await prefs.setStringList(_key, favs);
  }
}
