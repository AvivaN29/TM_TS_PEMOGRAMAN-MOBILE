import '../models/book_model.dart';

final List<Book> books = [
  const Book(
    title: 'Flutter untuk Pemula',
    author: 'Andi Wijaya',
    coverUrl: 'https://picsum.photos/200/300?1',
    description: 'Panduan lengkap belajar Flutter dari nol.',
  ),
  const Book(
    title: 'Dart Lanjutan',
    author: 'Budi Santoso',
    coverUrl: 'https://picsum.photos/200/300?2',
    description: 'Bahas Dart secara mendalam dan profesional.',
  ),
  const Book(
    title: 'Mobile UI Design',
    author: 'Siti Rahma',
    coverUrl: 'https://picsum.photos/200/300?3',
    description: 'Desain UI modern untuk aplikasi mobile.',
  ),
  const Book(
    title: 'Clean Code Flutter',
    author: 'Robert Clean',
    coverUrl: 'https://picsum.photos/200/300?4',
    description: 'Menulis kode Flutter yang rapi dan terstruktur.',
  ),
  const Book(
    title: 'State Management',
    author: 'Eko Prasetyo',
    coverUrl: 'https://picsum.photos/200/300?5',
    description: 'Provider, Riverpod, dan Bloc dijelaskan.',
  ),
  const Book(
    title: 'Firebase Flutter',
    author: 'Dewi Lestari',
    coverUrl: 'https://picsum.photos/200/300?6',
    description: 'Integrasi Flutter dengan Firebase.',
  ),
  const Book(
    title: 'REST API Flutter',
    author: 'Agus Saputra',
    coverUrl: 'https://picsum.photos/200/300?7',
    description: 'Consume REST API di Flutter.',
  ),
  const Book(
    title: 'UI Animations',
    author: 'Nina Kartika',
    coverUrl: 'https://picsum.photos/200/300?8',
    description: 'Animasi Flutter yang halus dan menarik.',
  ),
  const Book(
    title: 'Flutter Architecture',
    author: 'Rizki Mahendra',
    coverUrl: 'https://picsum.photos/200/300?9',
    description: 'Arsitektur aplikasi Flutter skala besar.',
  ),
  const Book(
    title: 'Flutter Best Practice',
    author: 'Admin',
    coverUrl: 'https://picsum.photos/200/300?10',
    description: 'Praktik terbaik dalam pengembangan Flutter.',
  ),
];
