class BookModel {
  final String title;
  final List<String> authors;
  final String image;
  final String description;

  BookModel({
    required this.title,
    required this.authors,
    required this.image,
    required this.description,
  });
}
