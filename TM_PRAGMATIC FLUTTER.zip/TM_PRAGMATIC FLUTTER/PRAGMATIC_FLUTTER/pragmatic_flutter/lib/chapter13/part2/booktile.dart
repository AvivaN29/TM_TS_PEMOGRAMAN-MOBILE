import 'package:flutter/material.dart';
import 'bookmodel.dart';
import 'book_detail_page.dart';

class BookTile extends StatelessWidget {
  final BookModel book;

  const BookTile({
    Key? key,
    required this.book,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      child: ListTile(
        title: Text(book.title),
        subtitle: Text('Author(s): ${book.authors.join(", ")}'),
        trailing: const Icon(Icons.arrow_forward),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BookDetailPage(book: book),
            ),
          );
        },
      ),
    );
  }
}
