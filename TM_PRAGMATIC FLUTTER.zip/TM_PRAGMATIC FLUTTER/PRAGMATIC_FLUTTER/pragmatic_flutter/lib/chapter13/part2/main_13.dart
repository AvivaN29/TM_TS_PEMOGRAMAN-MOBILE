import 'package:flutter/material.dart';
import 'bookmodel.dart';
import 'booktile.dart';

void main() {
  runApp(const BooksApp());
}

class BooksApp extends StatelessWidget {
  const BooksApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const BooksHomePage(),
    );
  }
}

class BooksHomePage extends StatelessWidget {
  const BooksHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final books = [
      BookModel(
        title: 'Flutter for Beginners',
        authors: ['Author One', 'Author Two'],
        image: 'assets/book_cover.png',
        description: 'This book is for Flutter beginners.',
      ),
      BookModel(
        title: 'Advanced Flutter',
        authors: ['Author One'],
        image: 'assets/book_cover.png',
        description: 'Advanced Flutter concepts.',
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Books Listing')),
      body: ListView.builder(
        itemCount: books.length,
        itemBuilder: (_, index) => BookTile(book: books[index]),
      ),
    );
  }
}
