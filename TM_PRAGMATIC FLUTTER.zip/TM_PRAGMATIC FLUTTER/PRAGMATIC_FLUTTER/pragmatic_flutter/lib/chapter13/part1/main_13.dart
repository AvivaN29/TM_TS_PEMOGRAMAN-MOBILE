import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

/// GANTI dengan API key kamu (atau pakai 'demo' dulu)
const String YOUR_API_KEY = 'demo';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BooksPage(),
    );
  }
}

class BooksPage extends StatefulWidget {
  const BooksPage({super.key});

  @override
  State<BooksPage> createState() => _BooksPageState();
}

class _BooksPageState extends State<BooksPage> {
  late Future<List<Book>> booksFuture;

  @override
  void initState() {
    super.initState();
    booksFuture = fetchBooks();
  }

  Future<List<Book>> fetchBooks() async {
    final url = Uri.parse(
      'https://www.googleapis.com/books/v1/volumes?q=flutter&key=$YOUR_API_KEY',
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List items = data['items'] ?? [];

      return items
          .map(
            (item) => Book(
              bookJson: item, // ✅ FIXED (WAJIB bookJson)
            ),
          )
          .toList();
    } else {
      throw Exception('Gagal mengambil data buku');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Books API'),
        centerTitle: true,
      ),
      body: FutureBuilder<List<Book>>(
        future: booksFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }

          final books = snapshot.data ?? [];

          return ListView.builder(
            itemCount: books.length,
            itemBuilder: (context, index) {
              final book = books[index];
              return ListTile(
                leading: book.thumbnail.isNotEmpty
                    ? Image.network(book.thumbnail, width: 50)
                    : const Icon(Icons.book),
                title: Text(book.title),
                subtitle: Text(book.authors),
              );
            },
          );
        },
      ),
    );
  }
}

/// =======================
/// MODEL BOOK (FIXED)
/// =======================
class Book {
  final String title;
  final String authors;
  final String thumbnail;

  Book({required Map<String, dynamic> bookJson})
      : title = bookJson['volumeInfo']?['title'] ?? 'No Title',
        authors = (bookJson['volumeInfo']?['authors'] as List?)?.join(', ') ??
            'Unknown Author',
        thumbnail = bookJson['volumeInfo']?['imageLinks']?['thumbnail'] ?? '';
}
