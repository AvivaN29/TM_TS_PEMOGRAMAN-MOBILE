import 'package:flutter/material.dart';
import '../part2/bookmodel.dart';
import '../book_detail_page.dart';

class BookTile extends StatelessWidget {
  final dynamic bookJson;

  const BookTile({Key? key, required this.bookJson}) : super(key: key);

  BookModel _toModel(dynamic json) {
    final volume = json['volumeInfo'] ?? {};
    final title = volume['title'] ?? 'No Title';
    final authors = (volume['authors'] != null)
        ? List<String>.from(volume['authors'])
        : <String>['Unknown Author'];
    String image = volume['imageLinks']?['thumbnail'] ?? '';
    image = image.replaceAll('http://', 'https://');
    final description = volume['description'] ?? '';
    return BookModel(
      title: title,
      authors: authors,
      image: image,
      description: description,
    );
  }

  @override
  Widget build(BuildContext context) {
    final model = _toModel(bookJson);

    return ListTile(
      leading: model.image.isNotEmpty
          ? Image.network(
              model.image,
              width: 50,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.book),
            )
          : const Icon(Icons.book),
      title: Text(model.title),
      subtitle: Text(model.authors.isNotEmpty ? model.authors[0] : 'Unknown'),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BookDetailPage(book: model),
          ),
        );
      },
    );
  }
}
