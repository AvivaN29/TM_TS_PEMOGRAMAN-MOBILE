import 'package:flutter/material.dart';

final ThemeData appTheme = ThemeData(
  useMaterial3: true,
  fontFamily: 'Pangolin',
  colorScheme: ColorScheme.fromSeed(
    seedColor: const Color(0xFF6A5AE0),
  ),
  scaffoldBackgroundColor: const Color(0xFFF7F5FB),
  cardTheme: CardThemeData(
    elevation: 6,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20),
    ),
  ),
);
