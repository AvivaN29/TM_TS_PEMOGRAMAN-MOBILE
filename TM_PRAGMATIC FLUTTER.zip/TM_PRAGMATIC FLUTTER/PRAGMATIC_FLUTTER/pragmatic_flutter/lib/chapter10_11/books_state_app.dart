import 'package:flutter/material.dart';

class BooksStateApp extends StatelessWidget {
  const BooksStateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Books App with State',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const BooksHomePage(),
    );
  }
}

class BooksHomePage extends StatefulWidget {
  const BooksHomePage({super.key});

  @override
  State<BooksHomePage> createState() => _BooksHomePageState();
}

class _BooksHomePageState extends State<BooksHomePage> {
  final List<Map<String, dynamic>> books = [
    {
      'title': 'Flutter for Beginners',
      'authors': ['Author One', 'Author Two'],
      'favorite': false,
    },
    {
      'title': 'Advanced Flutter',
      'authors': ['Author One'],
      'favorite': false,
    },
  ];

  void toggleFavorite(int index) {
    setState(() {
      books[index]['favorite'] = !books[index]['favorite'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Books Listing (with State)'),
      ),
      body: ListView.builder(
        itemCount: books.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(12),
            elevation: 4,
            child: ListTile(
              title: Text(
                books[index]['title'],
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Author(s): ${books[index]['authors'].join(', ')}',
              ),
              trailing: IconButton(
                icon: Icon(
                  books[index]['favorite']
                      ? Icons.favorite
                      : Icons.favorite_border,
                  color:
                      books[index]['favorite'] ? Colors.red : Colors.grey,
                ),
                onPressed: () => toggleFavorite(index),
              ),
            ),
          );
        },
      ),
    );
  }
}
