import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ================= APP ROOT =================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          bodyMedium: TextStyle(
            fontSize: 14,
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

// ================= HOME PAGE =================
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Local Theme Demo',
          style: textTheme.titleLarge,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ini title besar',
              style: textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            Text(
              'Ini body text menggunakan bodyMedium',
              style: textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            Theme(
              data: Theme.of(context).copyWith(
                textTheme: const TextTheme(
                  titleLarge: TextStyle(
                    color: Colors.red,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                  bodyMedium: TextStyle(
                    color: Colors.green,
                    fontSize: 14,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Tema lokal - Title'),
                  SizedBox(height: 8),
                  Text('Tema lokal - Body'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
