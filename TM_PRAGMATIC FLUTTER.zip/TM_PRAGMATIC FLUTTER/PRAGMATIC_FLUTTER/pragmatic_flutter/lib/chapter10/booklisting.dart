import 'package:flutter/material.dart';
import '../chapter15/book.dart';

class BookListing extends StatelessWidget {
  final List<Book> books;

  const BookListing({
    super.key,
    required this.books,
  });

  @override
  Widget build(BuildContext context) {
    if (books.isEmpty) {
      return const Center(
        child: Text('Belum ada buku'),
      );
    }

    return ListView.builder(
      itemCount: books.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(books[index].title),
        );
      },
    );
  }
}
