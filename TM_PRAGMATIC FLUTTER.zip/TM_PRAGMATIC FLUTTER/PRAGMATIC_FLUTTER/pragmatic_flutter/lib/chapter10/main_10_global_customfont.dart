import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ================= ROOT APP =================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      // ✅ GLOBAL CUSTOM FONT
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto', // pastikan font ada di pubspec.yaml
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          bodyMedium: TextStyle(fontSize: 14),
        ),
      ),

      home: const HomePage(),
    );
  }
}

// ================= HOME PAGE =================
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Global Custom Font'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Judul dengan font global',
              style: textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            Text(
              'Ini adalah contoh penggunaan custom font global '
              'yang diterapkan melalui ThemeData.',
              style: textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}
