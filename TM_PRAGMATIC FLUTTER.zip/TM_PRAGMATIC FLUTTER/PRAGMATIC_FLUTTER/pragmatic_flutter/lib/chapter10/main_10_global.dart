// Chapter 10 – Global Theme Demo (FIXED for older Dart & modern Flutter)

import 'package:flutter/material.dart';

/// ===============================
/// THEME DEFINITIONS
/// ===============================

ThemeData defaultTheme = ThemeData(
  brightness: Brightness.light,
  primaryColor: Colors.blue,
  colorScheme: ColorScheme.fromSwatch(
    primarySwatch: Colors.blue,
  ).copyWith(
    secondary: Colors.lightBlueAccent,
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: Colors.blue,
    iconTheme: IconThemeData(color: Colors.white),
  ),
);

ThemeData pinkTheme = ThemeData(
  brightness: Brightness.light,
  primaryColor: Colors.pink,
  colorScheme: ColorScheme.fromSwatch(
    primarySwatch: Colors.pink,
  ).copyWith(
    secondary: Colors.pinkAccent,
  ),
);

ThemeData darkTheme = ThemeData(
  brightness: Brightness.dark,
  primaryColor: Colors.orange,
  colorScheme: ColorScheme.fromSwatch(
    brightness: Brightness.dark,
    primarySwatch: Colors.orange,
  ).copyWith(
    secondary: Colors.yellowAccent,
  ),
);

/// ===============================
/// ROOT APP WIDGET
/// ===============================

class BooksApp extends StatelessWidget {
  BooksApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: defaultTheme,
      home: BooksHomePage(),
    );
  }
}

/// ===============================
/// HOME PAGE
/// ===============================

class BooksHomePage extends StatelessWidget {
  BooksHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.home),
        title: Text("Books Listing"),
      ),
      body: BooksListing(),
    );
  }
}

/// ===============================
/// DUMMY BOOK DATA
/// ===============================

List<Map<String, dynamic>> bookData() {
  return [
    {
      'title': 'Flutter for Beginners',
      'authors': ['Author One', 'Author Two'],
      'image': 'assets/book_cover.png',
    },
    {
      'title': 'Advanced Flutter',
      'authors': ['Author One'],
      'image': 'assets/book_cover.png',
    },
  ];
}

/// ===============================
/// BOOK LIST WIDGET
/// ===============================

class BooksListing extends StatelessWidget {
  BooksListing({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final booksListing = bookData();

    return ListView.builder(
      itemCount: booksListing.length,
      itemBuilder: (context, index) {
        final book = booksListing[index];

        return Card(
          elevation: 5,
          margin: EdgeInsets.all(10),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Padding(
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        book['title'],
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        "Author(s): ${book['authors'].join(', ')}",
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ),
                Image.asset(
                  book['image'],
                  width: 60,
                  height: 80,
                  fit: BoxFit.cover,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
