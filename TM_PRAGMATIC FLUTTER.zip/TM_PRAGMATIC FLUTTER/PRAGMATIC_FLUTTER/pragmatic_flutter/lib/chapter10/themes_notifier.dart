import 'package:flutter/material.dart';

class ThemesNotifier extends ChangeNotifier {
  bool _isDark = false;

  ThemeData get currentThemeData => _isDark ? _darkTheme : _lightTheme;

  void switchTheme() {
    _isDark = !_isDark;
    notifyListeners();
  }

  final ThemeData _lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blue,
      brightness: Brightness.light,
    ),
  );

  final ThemeData _darkTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blue,
      brightness: Brightness.dark,
    ),
  );
}
