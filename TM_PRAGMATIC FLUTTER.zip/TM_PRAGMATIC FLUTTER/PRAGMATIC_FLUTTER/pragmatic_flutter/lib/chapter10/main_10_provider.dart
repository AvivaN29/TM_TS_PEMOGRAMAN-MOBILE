import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// ================= ENTRY POINT =================
void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemesNotifier(),
      child: const MyApp(),
    ),
  );
}

// ================= ROOT APP =================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemesNotifier>(
      builder: (context, themeNotifier, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: themeNotifier.currentThemeData,
          home: const BooksHomePage(),
        );
      },
    );
  }
}

// ================= HOME PAGE =================
class BooksHomePage extends StatelessWidget {
  const BooksHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final themeNotifier = Provider.of<ThemesNotifier>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Books Listing'),
        actions: [
          IconButton(
            icon: const Icon(Icons.brightness_6),
            onPressed: themeNotifier.switchTheme,
          ),
        ],
      ),
      body: const BooksListing(),
    );
  }
}

// ================= BOOK LIST =================
class BooksListing extends StatelessWidget {
  const BooksListing({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(
          leading: Icon(Icons.book),
          title: Text('Flutter for Beginners'),
          subtitle: Text('John Doe'),
        ),
        ListTile(
          leading: Icon(Icons.book),
          title: Text('Dart Programming'),
          subtitle: Text('Jane Smith'),
        ),
      ],
    );
  }
}

// ================= THEME PROVIDER =================
class ThemesNotifier extends ChangeNotifier {
  bool _isDark = false;

  ThemeData get currentThemeData => _isDark ? _darkTheme : _lightTheme;

  void switchTheme() {
    _isDark = !_isDark;
    notifyListeners();
  }

  final ThemeData _lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blue,
      brightness: Brightness.light,
    ),
  );

  final ThemeData _darkTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blue,
      brightness: Brightness.dark,
    ),
  );
}
