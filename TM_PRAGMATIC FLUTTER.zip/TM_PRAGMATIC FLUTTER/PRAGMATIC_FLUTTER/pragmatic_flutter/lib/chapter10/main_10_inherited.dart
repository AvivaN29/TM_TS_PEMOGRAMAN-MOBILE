import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ================= APP ROOT =================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MyInheritedWidget(
      data: 'Hello InheritedWidget',
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.blue,
          ),
          useMaterial3: true,
        ),
        home: const HomePage(),
      ),
    );
  }
}

// ================= INHERITED WIDGET =================
class MyInheritedWidget extends InheritedWidget {
  final String data;

  const MyInheritedWidget({
    super.key,
    required this.data,
    required super.child,
  });

  static MyInheritedWidget? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<MyInheritedWidget>();
  }

  @override
  bool updateShouldNotify(MyInheritedWidget oldWidget) {
    return data != oldWidget.data;
  }
}

// ================= HOME PAGE =================
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final inherited = MyInheritedWidget.of(context)!; // null-check aman

    return Scaffold(
      appBar: AppBar(
        title: const Text('Inherited Widget Demo'),
      ),
      body: Center(
        child: Text(
          inherited.data,
          style: const TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
