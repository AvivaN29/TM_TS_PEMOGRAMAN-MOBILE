import 'package:flutter/material.dart';
import 'book_model.dart';

class BookTile extends StatelessWidget {
  final BookModel book;

  const BookTile({Key? key, required this.book}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10),
      child: ListTile(
        title: Text(book.title),
        subtitle: Text('Author(s): ${book.authors.join(", ")}'),
      ),
    );
  }
}
