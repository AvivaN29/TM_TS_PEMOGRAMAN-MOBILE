import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

/// =======================
/// APP
/// =======================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BooksPage(),
    );
  }
}

/// =======================
/// PAGE (STATIC DATA)
/// =======================
class BooksPage extends StatelessWidget {
  const BooksPage({super.key});

  /// ✅ FIX: data statis langsung di-init
  final List<BookModel> booksListing = const [
    BookModel(
      title: 'Flutter for Beginners',
      author: 'John Smith',
    ),
    BookModel(
      title: 'Dart Programming',
      author: 'Jane Doe',
    ),
    BookModel(
      title: 'Mobile App Development',
      author: 'Alex Johnson',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Books (Static Data)'),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: booksListing.length,
        itemBuilder: (context, index) {
          return BookTile(
            book: booksListing[index], // ✅ FIX
          );
        },
      ),
    );
  }
}

/// =======================
/// MODEL
/// =======================
class BookModel {
  final String title;
  final String author;

  const BookModel({
    required this.title,
    required this.author,
  });
}

/// =======================
/// TILE
/// =======================
class BookTile extends StatelessWidget {
  final BookModel book;

  const BookTile({super.key, required this.book});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: ListTile(
        leading: const Icon(Icons.book),
        title: Text(book.title),
        subtitle: Text(book.author),
      ),
    );
  }
}
