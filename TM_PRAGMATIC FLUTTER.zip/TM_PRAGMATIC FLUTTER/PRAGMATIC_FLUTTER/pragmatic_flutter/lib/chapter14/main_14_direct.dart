import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

/// API KEY (pakai demo dulu biar aman)
const String YOUR_API_KEY = 'demo';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BooksPage(),
    );
  }
}

/// =======================
/// PAGE
/// =======================
class BooksPage extends StatefulWidget {
  const BooksPage({super.key});

  @override
  State<BooksPage> createState() => _BooksPageState();
}

class _BooksPageState extends State<BooksPage> {
  /// ✅ FIX: di‐init
  List<BookModel> booksListing = [];

  @override
  void initState() {
    super.initState();
    fetchBooks();
  }

  Future<void> fetchBooks() async {
    final url = Uri.parse(
      'https://www.googleapis.com/books/v1/volumes?q=flutter&key=$YOUR_API_KEY',
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List items = data['items'] ?? [];

      setState(() {
        booksListing = items
            .map((json) => BookModel.fromJson(json)) // ✅ FIX
            .toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Books Direct API'),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: booksListing.length,
        itemBuilder: (context, index) {
          final book = booksListing[index];
          return BookTile(book: book); // ✅ FIX
        },
      ),
    );
  }
}

/// =======================
/// MODEL
/// =======================
class BookModel {
  final String title;
  final String author;
  final String thumbnail;

  BookModel({
    required this.title,
    required this.author,
    required this.thumbnail,
  });

  /// ✅ FIX: fromJson ADA
  factory BookModel.fromJson(Map<String, dynamic> json) {
    final volumeInfo = json['volumeInfo'] ?? {};

    return BookModel(
      title: volumeInfo['title'] ?? 'No Title',
      author: (volumeInfo['authors'] as List?)?.join(', ') ?? 'Unknown Author',
      thumbnail: volumeInfo['imageLinks']?['thumbnail'] ?? '',
    );
  }
}

/// =======================
/// WIDGET TILE
/// =======================
class BookTile extends StatelessWidget {
  final BookModel book; // ✅ FIX

  const BookTile({super.key, required this.book});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: ListTile(
        leading: book.thumbnail.isNotEmpty
            ? Image.network(book.thumbnail, width: 50)
            : const Icon(Icons.book),
        title: Text(book.title),
        subtitle: Text(book.author),
      ),
    );
  }
}
