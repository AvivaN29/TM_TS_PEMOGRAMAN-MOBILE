import 'dart:convert';
import 'package:http/http.dart' as http;
import 'book_model.dart';

class BookService {
  static Future<List<BookModel>> fetchBooks() async {
    final url = Uri.parse(
      'https://www.googleapis.com/books/v1/volumes?q=flutter',
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List items = data['items'];

      return items.map((e) => BookModel.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load books');
    }
  }
}
