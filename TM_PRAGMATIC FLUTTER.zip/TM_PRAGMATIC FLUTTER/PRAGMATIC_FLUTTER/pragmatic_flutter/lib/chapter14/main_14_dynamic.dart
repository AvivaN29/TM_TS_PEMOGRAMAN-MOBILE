import 'package:flutter/material.dart';
import 'book.dart';
import 'booktile.dart';
import 'book_details_page.dart';
import 'page_not_found.dart';

class BooksApiApp extends StatelessWidget {
  const BooksApiApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      onGenerateRoute: generateRoute,
    );
  }
}

Route<dynamic> generateRoute(RouteSettings settings) {
  final args = settings.arguments;

  switch (settings.name) {
    case '/':
      return MaterialPageRoute(builder: (_) => const BooksListing());

    case '/details':
      if (args is BookModel) {
        return MaterialPageRoute(
          builder: (_) => BookDetailsPage(book: args),
        );
      }
      return MaterialPageRoute(builder: (_) => PageNotFound());

    default:
      return MaterialPageRoute(builder: (_) => PageNotFound());
  }
}

class BooksListing extends StatefulWidget {
  const BooksListing({Key? key}) : super(key: key);

  @override
  State<BooksListing> createState() => _BooksListingState();
}

class _BooksListingState extends State<BooksListing> {
  final List<BookModel> booksListing = [
    BookModel(
      title: 'Flutter for Beginners',
      authors: ['Author One', 'Author Two'],
      description: 'Learn Flutter from scratch',
      image: 'assets/book_cover.png',
    ),
    BookModel(
      title: 'Advanced Flutter',
      authors: ['Author One'],
      description: 'Deep dive into Flutter',
      image: 'assets/book_cover.png',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Books Listing')),
      body: ListView.builder(
        itemCount: booksListing.length,
        itemBuilder: (_, index) {
          return BookTile(book: booksListing[index]);
        },
      ),
    );
  }
}
