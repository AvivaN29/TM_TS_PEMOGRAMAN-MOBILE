class BookModel {
  final String title;
  final List<String> authors;

  BookModel({
    required this.title,
    required this.authors,
  });

  factory BookModel.fromJson(Map<String, dynamic> json) {
    final volumeInfo = json['volumeInfo'] ?? {};

    return BookModel(
      title: volumeInfo['title'] ?? 'No Title',
      authors: volumeInfo['authors'] != null
          ? List<String>.from(volumeInfo['authors'])
          : ['Unknown Author'],
    );
  }
}
