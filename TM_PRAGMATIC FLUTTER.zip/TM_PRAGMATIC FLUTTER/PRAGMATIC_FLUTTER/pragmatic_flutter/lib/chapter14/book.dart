class BookModel {
  final String title;
  final List<String> authors;
  final String description;
  final String image;

  BookModel({
    required this.title,
    required this.authors,
    required this.description,
    required this.image,
  });
}
